import requests
import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import time
import uuid

# def  handler(event , context):
    
#     ip = requests.get("https://api.ipify.org?format=json").json()["ip"]
#     print(f"outbound IP {ip}")
#     return {"statusCode": 200, "body": ip}

dynamodb = boto3.resource('dynamodb')
filepool_table = dynamodb.Table('FilePool')
account_table = dynamodb.Table('AccountPool')
sqs = boto3.client('sqs')

def get_available_account():
    response = account_table.scan(
        FilterExpression=Attr('active_workflows').lt(2)
    )
    
    if not response['Items']:
        return None
    
    accounts = sorted(response['Items'], key=lambda x: x['active_workflows'])
    return accounts[0]

def acquire_account_slot(account_id):
    try:
        account_table.update_item(
            Key={'account_id': account_id},
            UpdateExpression='ADD active_workflows :inc',
            ConditionExpression=Attr('active_workflows').lt(2),
            ExpressionAttributeValues={
                ':inc': 1
            }
        )
        return True
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return False
        raise

def acquire_lock(workflow_id):
    response = filepool_table.query(
        IndexName='status-index',
        KeyConditionExpression=Key('status').eq('FREE'),
        Limit=1
    )
    
    if not response['Items']:
        return None
    
    file = response['Items'][0]
    now = int(time.time())
    ttl = now + (22 * 60)
    
    try:
        filepool_table.update_item(
            Key={'file_id': file['file_id']},
            UpdateExpression='SET #s = :locked, workflow_id = :wf_id, locked_at = :now, #t = :ttl',
            ConditionExpression=Attr('status').eq('FREE'),
            ExpressionAttributeNames={
                '#s': 'status',
                '#t': 'ttl'
            },
            ExpressionAttributeValues={
                ':locked': 'LOCKED',
                ':wf_id': workflow_id,
                ':now': now,
                ':ttl': ttl
            }
        )
        return file
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return None
        raise


def release_lock(file_id, workflow_id):
    try:
        filepool_table.update_item(
            Key={'file_id': file_id},
            UpdateExpression='SET #s = :free, workflow_id = :null, locked_at = :null, #t = :null',
            ConditionExpression=Attr('workflow_id').eq(workflow_id),
            ExpressionAttributeNames={
                '#s': 'status',
                '#t': 'ttl'
            },
            ExpressionAttributeValues={
                ':free': 'FREE',
                ':null': None
            }
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            print(f"Warning: unexpected lock state for {file_id}")
        else:
            raise

# def release_account_slot(account_id):
#     try:
#         account_table.update_item(
#             Key={'account_id': account_id},
#             UpdateExpression='ADD active_workflows :dec',
#             ConditionExpression=Attr('active_workflows').gt(0),
#             ExpressionAttributeValues={
#                 ':dec': -1
#             }
#         )
#     except ClientError as e:
#         if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
#             print(f"Warning: account {account_id} already at 0")
#         else:
#             raise
def send_to_spoke(account, payload):
    sqs.send_message(
        QueueUrl=account['queue_url'],
        MessageBody=json.dumps(payload)
    )
    print(f"Sent to account {account['account_id']} workflow {payload['workflow_id']}")

def lambda_handler(event, context):
    message = event['Records'][0]
    body = json.loads(message['body'])
    workflow_id = str(uuid.uuid4())  # generate here

    # Stage 1 — find available account
    account = get_available_account()
    if not account:
        print("No account available, retrying in 20 mins")
        return

    # Stage 2 — acquire file lock
    file = acquire_lock(workflow_id)
    if not file:
        print("No file available, retrying in 20 mins")
        return

    # Stage 3 — increment account slot
    success = acquire_account_slot(account['account_id'])
    if not success:
        print("Account slot gone, retrying in 20 mins")
        release_lock(file['file_id'], workflow_id)
        return

    # all three succeeded
    send_to_spoke(account, {
        'workflow_id': workflow_id,
        'file_id': file['file_id'],
        'search_term': body['search_term'],
        'target_bucket': body['target_bucket']
    })

